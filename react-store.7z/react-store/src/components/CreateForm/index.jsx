import React, { useState } from 'react';
import { createProduct } from '../../utils/createProduct';
import 'bulma/css/bulma.min.css';
import Swal from 'sweetalert2';

const CreateForm = () => {
  const [formData, setFormData] = useState({
    title: '',
    price: '',
    category: '',
    description: '',
    image: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await createProduct(formData);
      // Reset form fields
      setFormData({
        title: '',
        price: '',
        category: '',
        description: '',
        image: ''
      });

      // Show success notification
      Swal.fire('Producto creado!', '', 'success');
    } catch (error) {
      // Handle error
    }
  };

  return (
    <div className="create-form">
      <div className="columns is-centered">
        <div className="column is-one-third">
          <form onSubmit={handleSubmit}>
            <div className="field">
              <label className="label">Nombre</label>
              <div className="control">
                <input
                  className="input"
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="field">
              <label className="label">Precio</label>
              <div className="control">
                <input
                  className="input"
                  type="text"
                  name="price"
                  value={formData.price}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="field">
              <label className="label">Categoria</label>
              <div className="control">
                <input
                  className="input"
                  type="text"
                  name="category"
                  value={formData.category}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="field">
              <label className="label">Descripcion</label>
              <div className="control">
                <textarea
                  className="textarea"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="field">
              <label className="label">Imagen</label>
              <div className="control">
                <input
                  className="input"
                  type="text"
                  name="image"
                  value={formData.image}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="field">
              <div className="control">
                <button className="button is-info" type="submit">
                  Crear Producto
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateForm;
