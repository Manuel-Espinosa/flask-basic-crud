import React, { useEffect, useState } from "react";
import { getProducts } from "../../utils/getProducts";
import { Link } from "react-router-dom";
import "bulma/css/bulma.min.css";

const Dashboard = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const data = await getProducts();
        setProducts(data);
      } catch (error) {
        // Handle error
      }
    };

    fetchProducts();
  }, []);

  const handleRemove = (id) => {
    // Logic to remove the product with the given id
    const updatedProducts = products.filter((product) => product.id !== id);
    setProducts(updatedProducts);
  };

  return (
    <div className="dashboard">
      <div className="columns is-multiline">
        {products.map((product) => (
          <div key={product.id} className="column is-one-third">
            <div className="card">
              <div className="card-content">
                <div className="media">
                  <div className="media-left">
                    <figure className="image is-64x64">
                      <img src={product.image} alt={product.title} />
                    </figure>
                  </div>
                  <div className="media-content">
                    <p className="title is-4">{product.title}</p>
                    <p className="subtitle is-6">{product.category}</p>
                  </div>
                </div>
                <div className="content">
                  {product.description}
                  <br />
                  Price: ${product.price}
                </div>
              </div>
              <footer className="card-footer">
                <a
                  href="#"
                  className="card-footer-item"
                  onClick={() => handleRemove(product.id)}
                >
                  Eliminar
                </a>
                <Link
                  to={`/update/${product.id}`}
                  className="card-footer-item"
                >
                  Actualizar
                </Link>
              </footer>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
