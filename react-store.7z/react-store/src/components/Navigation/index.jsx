import React from 'react';
import { Link } from 'react-router-dom';
import 'bulma/css/bulma.min.css';


const Navigation = () => {
    return (
      <nav className="navbar is-info">
        <div className="navbar-brand">
          <span className="navbar-item">Fake Store</span>
        </div>
        <div className="navbar-menu">
          <div className="navbar-start">
            <Link to="/" className="navbar-item">
              Dashboard
            </Link>
            <Link to="/update" className="navbar-item">
              Actualizar Producto
            </Link>
            <Link to="/create" className="navbar-item">
              Agregar Producto
            </Link>
          </div>
        </div>
      </nav>
    );
  };

export default Navigation;
