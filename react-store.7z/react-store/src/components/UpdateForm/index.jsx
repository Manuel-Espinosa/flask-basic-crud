import React, { useState, useEffect } from "react";
import updateProduct from "../../utils/updateProducts";
import { useParams } from "react-router-dom";
import { getProducts } from "../../utils/getProducts";
import "bulma/css/bulma.min.css";
import Swal from "sweetalert2";

const UpdateForm = ({ onUpdate }) => {
  const { id } = useParams();
  const [selectedProductId, setSelectedProductId] = useState("");
  const [products, setProducts] = useState([]);
  const [formData, setFormData] = useState({
    title: "",
    price: "",
    description: "",
    image: "",
    category: "",
  });

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const fetchedProducts = await getProducts();
        setProducts(fetchedProducts);
      } catch (error) {
        // Handle error
      }
    };

    fetchProducts();
  }, []);

  useEffect(() => {
    // Set the initial form data based on the selected product's id
    const selectedProduct = products.find((product) => product.id === id);
    if (selectedProduct) {
      const { title, price, description, image, category } = selectedProduct;
      setSelectedProductId(selectedProduct.id);
      setFormData({
        title: title || "",
        price: price || "",
        description: description || "",
        image: image || "",
        category: category || "",
      });
    } else {
      setSelectedProductId("");
      setFormData({
        title: "",
        price: "",
        description: "",
        image: "",
        category: "",
      });
    }
  }, [id, products]);

  const handleProductChange = (event) => {
    const productId = event.target.value;
    setSelectedProductId(productId);
    const selectedProduct = products.find(
      (product) => product.id === productId
    );
    if (selectedProduct) {
      const { title, price, description, image, category } = selectedProduct;
      setFormData({
        title: title || "",
        price: price || "",
        description: description || "",
        image: image || "",
        category: category || "",
      });
    } else {
      setFormData({
        title: "",
        price: "",
        description: "",
        image: "",
        category: "",
      });
    }
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await updateProduct(selectedProductId, formData);
      Swal.fire({
        icon: "success",
        title: "Product Updated",
        showConfirmButton: false,
        timer: 1500,
      });
    } catch (error) {
      console.error(error);
      Swal.fire({
        icon: "error",
        title: "Oops!",
        text: "An error occurred while updating the product. Please try again.",
      });
    }
  };

  return (
    <div className="update-form">
      <div className="columns is-centered">
        <div className="column is-one-third">
          <form className="form" onSubmit={handleSubmit}>
            {products.length > 0 && (
              <div className="field">
                <label className="label">Producto</label>
                <div className="control">
                  <div className="select select-width">
                    <select
                      value={selectedProductId}
                      onChange={handleProductChange}
                      required
                    >
                      <option value="" disabled>
                        Select a product
                      </option>
                      {products.map((product) => (
                        <option key={product.id} value={product.id}>
                          {product.title}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            )}
            {selectedProductId && (
              <>
                <div className="field">
                  <label className="label">Nombre</label>
                  <div className="control">
                    <input
                      className="input"
                      type="text"
                      name="title"
                      value={formData.title}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
                <div className="field">
                  <label className="label">Precio</label>
                  <div className="control">
                    <input
                      className="input"
                      type="number"
                      name="price"
                      value={formData.price}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
                <div className="field">
                  <label className="label">Descripcion</label>
                  <div className="control">
                    <textarea
                      className="textarea"
                      name="description"
                      value={formData.description}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
                <div className="field">
                  <label className="label">Imagen</label>
                  <div className="control">
                    <input
                      className="input"
                      type="text"
                      name="image"
                      value={formData.image}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
                <div className="field">
                  <label className="label">Categoria</label>
                  <div className="control">
                    <input
                      className="input"
                      type="text"
                      name="category"
                      value={formData.category}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
                <div className="field">
                  <div className="control">
                    <button className="button is-info" type="submit">
                      Actualizar
                    </button>
                  </div>
                </div>
              </>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default UpdateForm;
