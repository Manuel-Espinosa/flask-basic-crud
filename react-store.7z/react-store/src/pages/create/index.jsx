import React from "react";
import Layout from "../../components/Layout";
import CreateForm from "../../components/CreateForm";
const Create = () => {
    return (
        <Layout>
            <CreateForm/>
        </Layout>
    )
}

export default Create