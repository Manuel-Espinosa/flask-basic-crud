import React from "react";
import Layout from "../../components/Layout";
import UpdateForm from "../../components/UpdateForm";
const Update = () => {
    return (
        <Layout>
            <UpdateForm/>
        </Layout>
    )
}

export default Update