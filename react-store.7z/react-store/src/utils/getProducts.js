import axios from "axios";

export const getProducts = async () => {
  try {
    const options = { method: "GET", url: "http://localhost:5000/products" };
    const response = await axios.request(options);
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.error(error);
    throw error;
  }
};
