import axios from 'axios';

const updateProduct = async (id, updatedProductData) => {
  try {
    const options = {
      method: 'PUT',
      url: `http://localhost:5000/product/${id}`,
      headers: { 'Content-Type': 'application/json' },
      data: updatedProductData,
    };

    const response = await axios.request(options);
    return response.data;
  } catch (error) {
    console.error(error);
    throw error;
  }
};

export default updateProduct;
