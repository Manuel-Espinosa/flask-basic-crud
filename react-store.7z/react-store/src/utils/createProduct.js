import axios from 'axios';

export const createProduct = async (productData) => {
  try {
    const options = {
      method: 'POST',
      url: 'http://localhost:5000/products',
      headers: {'Content-Type': 'application/json'},
      data: productData
    };

    const response = await axios.request(options);
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.error(error);
    throw error;
  }
};
